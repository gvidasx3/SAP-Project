Technologies needed: XAMPP and Code editor e.g Notepad++
Extract all files from github
Cut and paste the folder into C:Drive - XAMPP - htdocs
Open the db folder and access test_db.sql file with a code editor
Copy the SQL code in that file
Launch XAMPP and run apache and MYSQL in admin
In phpMyAdmin create a database called test_db and in that paste in the SQL code in the SQL section and press go
Go to back to your XAMMP and press admin for apache. In it change the url from localhost:/dashboard to profile-system instead of dashboard
Press enter
The application should work then.